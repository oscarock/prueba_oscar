@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ver Usuarios</div>

                <div class="panel-body">
	                <table class="table">
						<thead>
							<tr>
								<th>Asunto</th>
								<th>Destinatario</th>
								<th>Mensaje</th>
								<th>Mail Creado por:</th>
								<th>Fecha Creado</th>
								<th>Enviar Mail</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								@foreach ($mails as $mail)
								<tr>
									<th>{{$mail->asunto}}</th>
									<th>{{$mail->destinatario}}</th>
									<th>{{$mail->mensaje }}</th>
									<th>{{$mail->email }}</th>
									<th>{{$mail->created_at}}<th>
									<th><a href="sendMail/{{$mail->id}}" class="btn btn-warning">Enviar Mail</a></th>
								</tr>
								@endforeach
							</tr>	
						</tbody>
					</tables>
				</div>	
			</div>
        </div>
    </div>
</div>
@endsection
