@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Registrar Mail</div>

                <div class="panel-body">
                   {!! Form::open(['route'=>'mails.store', 'method'=>'POST', 'class' => 'form-horizontal', 'role' => 'form']) !!}
                        <div class="form-group">
                          <label for="usr">Asunto:</label>
                          <input type="text" class="form-control" name="asunto">
                        </div>
                        <!--Validacion de campos -->
                        @if($errors->has())
                            <div class="errors">                              
                                @if ($errors->has('asunto'))              
                                    {{ $errors->first('asunto') }}</br>               
                                @endif  
                            </div>
                        @endif
                        <div class="form-group">
                          <label for="usr">Destinatario:</label>
                          <input type="text" class="form-control" name="destinatario">
                        </div>
                        <!--Validacion de campos -->
                        @if($errors->has())
                            <div class="errors">                              
                                @if ($errors->has('destinatario'))              
                                    {{ $errors->first('destinatario') }}</br>               
                                @endif  
                            </div>
                        @endif 
                        <div class="form-group">
                          <label for="usr">Mensaje:</label>
                          <textarea class="form-control" name="mensaje"></textarea>
                        </div>
                        <!--Validacion de campos -->
                        @if($errors->has())
                            <div class="errors">                              
                                @if ($errors->has('mesaje'))              
                                    {{ $errors->first('mesaje') }}</br>               
                                @endif  
                            </div>
                        @endif
                        <div class="form-group">
                          <label for="usr">Estado del mail:</label>
                          <select class="form-control" name="estado">
                              <option value="Seleccione">--Seleccione--</option>
                              <option value="0">Pendiente</option>
                               <option value="1">Enviar</option>
                          </select>
                        </div> 
                        <div class="form-group">
                          <input type="submit" class="btn btn-success" >
                        </div>  
                   {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
