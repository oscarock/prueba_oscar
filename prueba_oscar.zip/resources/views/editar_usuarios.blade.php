@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Registrar Usuarios</div>

                <div class="panel-body">
                   {!! Form::open(['route'=>['usuarios.update', $user->id], 'method'=>'PUT', 'class' => 'form-horizontal', 'role' => 'form']) !!}
                        <div class="form-group">
                          <label for="usr">Nombre:</label>
                          <input type="text" class="form-control" name="name" value="{!! $user->name !!}">
                        </div>
                        <div class="form-group">
                          <label for="usr">Email:</label>
                          <input type="text" class="form-control" name="email" value="{!! $user->email !!}">
                        </div>
                         <div class="form-group">
                          <label for="usr">Ciudad:</label>
                          <select class="form-control" name="location">
                              <option value="Seleccione">--Seleccione--</option>
                               <option value="--Seleccione--">Cali</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <input type="submit" class="btn btn-success" >
                        </div>  
                   {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
