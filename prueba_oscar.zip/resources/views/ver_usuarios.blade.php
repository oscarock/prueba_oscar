@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ver Usuarios</div>

                <div class="panel-body">
	                <table class="table">
						<thead>
							<tr>
								<th>Name</th>
								<th>Email</th>
								<th>Fecha Creado</th>
								<th>Editar</th>
								<th>Eliminar</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								@foreach ($users as $user)
								<tr>
									<th>{{$user->name}}</th>
									<th>{{$user->email}}</th>
									<th>{{$user->created_at}}<th>
									<th><a href="usuarios/{{$user->id}}/edit">Editar</a></th>
									<th>
										{{Form::open(array('url' => 'usuarios/'.$user->id, 'method' => 'DELETE' ))}}
												{{ Form::button('No', array('class' => 'btn btn-default')) }}
												{{ Form::submit('Si', array('class' => 'btn btn-danger')) }}
										{{ Form::close() }}
									</th>
								</tr>
								@endforeach
							</tr>	
						</tbody>
					</tables>
				</div>	
			</div>
        </div>
    </div>
</div>
@endsection
