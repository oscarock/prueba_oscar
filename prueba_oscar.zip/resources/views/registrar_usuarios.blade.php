@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Registrar Usuarios</div>

                <div class="panel-body">
                   {!! Form::open(['route'=>'usuarios.store', 'method'=>'POST', 'class' => 'form-horizontal', 'role' => 'form']) !!}
                        <div class="form-group">
                          <label for="usr">Nombre:</label>
                          <input type="text" class="form-control" name="name">
                        </div>
                        <!--Validacion de campos -->
                        @if($errors->has())
                            <div class="errors">                              
                                @if ($errors->has('name'))              
                                    {{ $errors->first('name') }}</br>               
                                @endif  
                            </div>
                        @endif
                        <div class="form-group">
                          <label for="usr">Email:</label>
                          <input type="text" class="form-control" name="email">
                        </div>
                         <!--Validacion de campos -->
                        @if($errors->has())
                            <div class="errors">                              
                                @if ($errors->has('email'))              
                                    {{ $errors->first('email') }}</br>               
                                @endif  
                            </div>
                        @endif
                         <div class="form-group">
                          <label for="usr">Ciudad:</label>
                          <select class="form-control" name="location">
                              <option value="Seleccione">--Seleccione--</option>
                               <option value="--Seleccione--">Cali</option>
                          </select>
                        </div>
                        <!--Validacion de campos -->
                        @if($errors->has())
                            <div class="errors">                              
                                @if ($errors->has('password'))              
                                    {{ $errors->first('password') }}</br>               
                                @endif  
                            </div>
                        @endif
                        <div class="form-group">
                          <label for="usr">Password:</label>
                          <input type="password" class="form-control" name="password">
                        </div>
                        <div class="form-group">
                          <label for="pwd">Repetir Password:</label>
                          <input type="password" class="form-control" name="password_confirmation">
                        </div>
                        <div class="form-group">
                          <input type="submit" class="btn btn-success" >
                        </div>  
                   {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
