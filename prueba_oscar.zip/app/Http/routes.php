<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::auth();

Route::get('/home', 'HomeController@index');

/*CRUD USUARIOS*/
Route::resource('usuarios','UserController');
/*FIN CRUD USUARIOS*/

/*CRUD MAILS*/
Route::resource('mails','MailController');
/*FIN CRUD MAILS*/

Route::get('sendMail/{id}','MailController@sendMail');