<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use App\Mails;
use Redirect;
use DB;

class MailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $mails = DB::table('mails')
            ->join('users', 'mails.usuario_send', '=', 'users.id')
            ->select('mails.*', 'users.email')
            ->get();

        return view('ver_mails',compact('mails'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('crear_mail');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
         $reglas = array(
            'asunto' => 'required',
            'destinatario' => 'required',
            'mensaje' => 'required|',
        );

        $validation = \Validator::make($request->all(),$reglas);

        //if validation fails to redirect forms with errors

        if ($validation->fails()){
            return Redirect::to('mails/create')->withErrors($validation)->withInput($request->all());
        }

        $mail  = new Mails;
        $mail->asunto = $request->input('asunto');
        $mail->destinatario = $request->input('destinatario');
        $mail->mensaje = $request->input('mensaje');
        $mail->estado = $request->input('estado');
        $mail->usuario_send = \Auth::user()->id; 
        $mail->save();

        /*$data = array(
            'asunto' => $request->input('asunto'),
            'destinatario' => $request->input('destinatario'),
            'mensaje' => $request->input('mensaje'),
            'usuario_send' => Auth::user()->id
        );
        
        $fromEmail = $request->input('destinatario');
        $fromName = $request->input('mensaje');

        \Mail::send('emails.sendMail', $data, function($message) use ($fromName, $fromEmail){

            $message->to($fromEmail, $fromName);
            $message->from(Auth::user()->email, $fromName);
            $message->subject($fromName);
        });*/

       return Redirect::to('mails');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function sendMail($id){

        $mails = Mails::find($id);
         
        $data = array(
            'asunto' => $mails->asunto,
            'destinatario' => $mails->destinatario,
            'mensaje' => $mails->mensaje,
            'usuario_send' => Auth::user()->id
        );
        
        $fromEmail = $mails->destinatario;
        $fromName = $mails->mensaje;
        $fromUsuario = $mails->usuario_send;

        \Mail::send('emails.sendMail', $data, function($message) use ($fromName, $fromEmail,$fromUsuario){

            $message->to($fromEmail, $fromName);
            $message->from(Auth::user()->email, $fromName);
            $message->subject($fromName);
        });

        $this->updateMail($id);

        return Redirect::to('mails');

    }

    public function updateMail($id){

        $data = DB::update('update mails set estado = 1 where estado = ?', array($id));

        return $data;
    }

}
