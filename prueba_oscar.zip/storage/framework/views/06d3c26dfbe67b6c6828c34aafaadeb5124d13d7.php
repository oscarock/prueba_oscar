<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ver Usuarios</div>

                <div class="panel-body">
	                <table class="table">
						<thead>
							<tr>
								<th>Asunto</th>
								<th>Destinatario</th>
								<th>Mensaje</th>
								<th>Mail Creado por:</th>
								<th>Fecha Creado</th>
								<th>Enviar Mail</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<?php foreach($mails as $mail): ?>
								<tr>
									<th><?php echo e($mail->asunto); ?></th>
									<th><?php echo e($mail->destinatario); ?></th>
									<th><?php echo e($mail->mensaje); ?></th>
									<th><?php echo e($mail->email); ?></th>
									<th><?php echo e($mail->created_at); ?><th>
									<th><a href="sendMail/<?php echo e($mail->id); ?>" class="btn btn-warning">Enviar Mail</a></th>
								</tr>
								<?php endforeach; ?>
							</tr>	
						</tbody>
					</tables>
				</div>	
			</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>