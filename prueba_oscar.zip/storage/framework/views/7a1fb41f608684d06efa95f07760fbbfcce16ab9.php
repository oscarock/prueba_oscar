<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Ver Usuarios</div>

                <div class="panel-body">
	                <table class="table">
						<thead>
							<tr>
								<th>Name</th>
								<th>Email</th>
								<th>Fecha Creado</th>
								<th>Editar</th>
								<th>Eliminar</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<?php foreach($users as $user): ?>
								<tr>
									<th><?php echo e($user->name); ?></th>
									<th><?php echo e($user->email); ?></th>
									<th><?php echo e($user->created_at); ?><th>
									<th><a href="usuarios/<?php echo e($user->id); ?>/edit">Editar</a></th>
									<th>
										<?php echo e(Form::open(array('url' => 'usuarios/'.$user->id, 'method' => 'DELETE' ))); ?>

												<?php echo e(Form::button('No', array('class' => 'btn btn-default'))); ?>

												<?php echo e(Form::submit('Si', array('class' => 'btn btn-danger'))); ?>

										<?php echo e(Form::close()); ?>

									</th>
								</tr>
								<?php endforeach; ?>
							</tr>	
						</tbody>
					</tables>
				</div>	
			</div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>