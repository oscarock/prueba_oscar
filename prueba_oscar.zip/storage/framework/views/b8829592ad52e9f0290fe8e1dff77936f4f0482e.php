<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Registrar Usuarios</div>

                <div class="panel-body">
                   <?php echo Form::open(['route'=>['usuarios.update', $user->id], 'method'=>'PUT', 'class' => 'form-horizontal', 'role' => 'form']); ?>

                        <div class="form-group">
                          <label for="usr">Nombre:</label>
                          <input type="text" class="form-control" name="name" value="<?php echo $user->name; ?>">
                        </div>
                        <div class="form-group">
                          <label for="usr">Email:</label>
                          <input type="text" class="form-control" name="email" value="<?php echo $user->email; ?>">
                        </div>
                         <div class="form-group">
                          <label for="usr">Ciudad:</label>
                          <select class="form-control" name="location">
                              <option value="Seleccione">--Seleccione--</option>
                               <option value="--Seleccione--">Cali</option>
                          </select>
                        </div>
                        <div class="form-group">
                          <input type="submit" class="btn btn-success" >
                        </div>  
                   <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>