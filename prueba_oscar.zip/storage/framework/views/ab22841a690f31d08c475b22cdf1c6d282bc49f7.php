<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Registrar Mail</div>

                <div class="panel-body">
                   <?php echo Form::open(['route'=>'mails.store', 'method'=>'POST', 'class' => 'form-horizontal', 'role' => 'form']); ?>

                        <div class="form-group">
                          <label for="usr">Asunto:</label>
                          <input type="text" class="form-control" name="asunto">
                        </div>
                        <!--Validacion de campos -->
                        <?php if($errors->has()): ?>
                            <div class="errors">                              
                                <?php if($errors->has('asunto')): ?>              
                                    <?php echo e($errors->first('asunto')); ?></br>               
                                <?php endif; ?>  
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                          <label for="usr">Destinatario:</label>
                          <input type="text" class="form-control" name="destinatario">
                        </div>
                        <!--Validacion de campos -->
                        <?php if($errors->has()): ?>
                            <div class="errors">                              
                                <?php if($errors->has('destinatario')): ?>              
                                    <?php echo e($errors->first('destinatario')); ?></br>               
                                <?php endif; ?>  
                            </div>
                        <?php endif; ?> 
                        <div class="form-group">
                          <label for="usr">Mensaje:</label>
                          <textarea class="form-control" name="mensaje"></textarea>
                        </div>
                        <!--Validacion de campos -->
                        <?php if($errors->has()): ?>
                            <div class="errors">                              
                                <?php if($errors->has('mesaje')): ?>              
                                    <?php echo e($errors->first('mesaje')); ?></br>               
                                <?php endif; ?>  
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                          <label for="usr">Estado del mail:</label>
                          <select class="form-control" name="estado">
                              <option value="Seleccione">--Seleccione--</option>
                              <option value="0">Pendiente</option>
                               <option value="1">Enviar</option>
                          </select>
                        </div> 
                        <div class="form-group">
                          <input type="submit" class="btn btn-success" >
                        </div>  
                   <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>