<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Registrar Usuarios</div>

                <div class="panel-body">
                   <?php echo Form::open(['route'=>'usuarios.store', 'method'=>'POST', 'class' => 'form-horizontal', 'role' => 'form']); ?>

                        <div class="form-group">
                          <label for="usr">Nombre:</label>
                          <input type="text" class="form-control" name="name">
                        </div>
                        <!--Validacion de campos -->
                        <?php if($errors->has()): ?>
                            <div class="errors">                              
                                <?php if($errors->has('name')): ?>              
                                    <?php echo e($errors->first('name')); ?></br>               
                                <?php endif; ?>  
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                          <label for="usr">Email:</label>
                          <input type="text" class="form-control" name="email">
                        </div>
                         <!--Validacion de campos -->
                        <?php if($errors->has()): ?>
                            <div class="errors">                              
                                <?php if($errors->has('email')): ?>              
                                    <?php echo e($errors->first('email')); ?></br>               
                                <?php endif; ?>  
                            </div>
                        <?php endif; ?>
                         <div class="form-group">
                          <label for="usr">Ciudad:</label>
                          <select class="form-control" name="location">
                              <option value="Seleccione">--Seleccione--</option>
                               <option value="--Seleccione--">Cali</option>
                          </select>
                        </div>
                        <!--Validacion de campos -->
                        <?php if($errors->has()): ?>
                            <div class="errors">                              
                                <?php if($errors->has('password')): ?>              
                                    <?php echo e($errors->first('password')); ?></br>               
                                <?php endif; ?>  
                            </div>
                        <?php endif; ?>
                        <div class="form-group">
                          <label for="usr">Password:</label>
                          <input type="password" class="form-control" name="password">
                        </div>
                        <div class="form-group">
                          <label for="pwd">Repetir Password:</label>
                          <input type="password" class="form-control" name="password_confirmation">
                        </div>
                        <div class="form-group">
                          <input type="submit" class="btn btn-success" >
                        </div>  
                   <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>